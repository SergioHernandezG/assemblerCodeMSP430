#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "drivers/pinout.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "utils/uartstdio.h"
#include <stdio.h>
#include <math.h>
#include <string.h>
#include "inc/hw_nvic.h"
#include "inc/hw_memmap.h"
#define DWT_O_CYCCNT 0x00000004

static uint32_t c_start, c_stop;
uint32_t g_ui32SysClock;

#ifdef DEBUG
void
__error__(char *pcFilename, uint32_t ui32Line)
{
}
#endif

void EnableTiming(void){

static int enabled = 0;

if (!enabled){

   HWREG(NVIC_DBG_INT) |= 0x01000000;            /*enable TRCENA bit in NVIC_DBG_INT*/

   HWREG(DWT_BASE + DWT_O_CYCCNT) = 0;           /* reset the counter */

   HWREG(DWT_BASE) |= 0x01;                      /* enable the counter */

   enabled = 1;

 }

}

void ConfigureUART(void) {
ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
ROM_GPIOPinConfigure(GPIO_PA0_U0RX);
ROM_GPIOPinConfigure(GPIO_PA1_U0TX);
ROM_GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
UARTStdioConfig(0, 115200, g_ui32SysClock);
}

int main(void) {
g_ui32SysClock = MAP_SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ |
SYSCTL_OSC_MAIN | SYSCTL_USE_PLL |
SYSCTL_CFG_VCO_480), 120000000);

PinoutSet(false, false);

ROM_GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_1);
ConfigureUART();

int real,tiempo,imag,N,i,k,x[]={1,2,3,4,1,2,3,4,1,2,3,4,1,2,3,4,1,2,3,4,1,2,3,4,1,2,3,4,1,2,3,4,1,2,3,4,1,2,3,4,1,2,3,4,1,2,3,4,1,2,3,4,1,2,3,4,1,2,3,4,1,2,3,4};
float Gr,Hr,Gi,Hi,Hi2,Hr2;
N=64;
c_start = HWREG(DWT_BASE + DWT_O_CYCCNT);
for (k=0;k<N;k++){
    Gr=0;
    Gi=0;
    Hr=0;
    Hi=0;
    for (i=0;i<(N/2);i++){
        Gr=Gr+x[2*i]*cosf(i*k*2*3.1416*2/N);
        Gi=Gi-x[2*i]*sinf(i*k*2*3.1416*2/N);
        Hr=Hr+x[2*i+1]*cosf(i*k*2*3.1416*2/N);
        Hi=Hi-x[2*i+1]*sinf(i*k*2*3.1416*2/N);
    }
    Hr2=Hr*cosf(2*3.1416*k/N)-Hi*sinf(2*3.1416*k/N);
    Hi2=-Hr*sinf(2*3.1416*k/N)+Hi*cosf(2*3.1416*k/N);
    real=Gr+Hr2;
    imag=Gi+Hi2;
    UARTprintf("%d %dj\n",real,imag);
}
c_stop = HWREG(DWT_BASE + DWT_O_CYCCNT);
tiempo=(c_stop - c_start); // por 12MHz
UARTprintf("%d",tiempo);
while(1)
{
LEDWrite(CLP_D1, 1);
SysCtlDelay(g_ui32SysClock / 10 / 3);
LEDWrite(CLP_D1, 0);
SysCtlDelay(g_ui32SysClock / 10 / 3);
}
}
